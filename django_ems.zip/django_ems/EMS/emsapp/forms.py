from django import forms
from emsapp.models import *

class Contactform(forms.ModelForm):
    
    class Meta:
        model = ContactEnquiry
        fields = ('name','email','message')

