from django.contrib import admin
from django.urls import path
from emsapp import views

urlpatterns = [
    path('home/<int:num>/' , views.home),
    path('' , views.index),
    path('get/', views.getData , name='getdata'),
    path('about/', views.about),
    path('addData/', views.addData , name='addData'),
    path('updatedata/<int:id>/' , views.updateData ,name='updatedata'),
    path('delete/<int:id>/' , views.deleteData , name='delete'),
    path('contact/', views.contactview , name='contact'),
    path('register/', views.register ),
    path('login/', views.login_view , name='login'),
    path('logout/', views.logout_view , name='logout' ),
]
