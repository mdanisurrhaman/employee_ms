from django.shortcuts import render,redirect
from django.http import HttpResponse
from emsapp.models import *
from emsapp.forms import *
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login , logout
from django.contrib.auth.decorators import login_required
# Create your views here.


def home(request,num):
    return HttpResponse(num )

def index(request):
   data={
       'info':[{'name':'abc','age':21},
               {'name':'xyz','age':20},
               {'name':'def','age':19}],
       'products':['dryfruits','spices','rice']
   }
   return render(request , 'index.html', data)

@login_required
def getData(request):
    employee=Employee.objects.all()
    department=Department.objects.all()
    return render(request, 'index.html' , context={'emp':employee, 'dep': department})


def about(request):
    # if request.method=='POST':
    #     name=request.Post['name']
    #     Employee.objects.create(name=name)
    #     return redirect('get_employees')
    return render(request,'about.html')

def addData(request):
    if request.method=='POST':
        name=request.POST['name']
        department=request.POST['department']
        salary=request.POST['salary']
        age=request.POST['age']
        Employee.objects.create(name=name,department=department,salary=salary,age=age)
        return redirect('getdata')
    return render(request, 'add_data.html')

def updateData(request,id):
    employee=Employee.objects.get(id=id)
    if request.method=='POST':
        employee.name=request.POST['name']
        employee.department=request.POST['department']
        employee.salary=request.POST['salary']
        employee.age=request.POST['age']
        employee.save()
        return redirect('getdata')
    
    return render(request , 'update.html',context={'emp':employee})

def deleteData(request,id):
    employee=Employee.objects.get(id=id)
    employee.delete()
    return redirect('getdata')

@login_required
def contactview(request):
    cform=Contactform()
    if request.method=='POST':
        cform=Contactform(request.POST)
        cform.save()
        return redirect('contact')
    
    return render(request, 'contact.html' , {'f': cform})

# -------------user registeration-----------------------------
def register(request):
    rform=UserCreationForm()
    if request.method=='POST':
        rform=UserCreationForm(request.POST)
        if rform.is_valid():
          rform.save()
          return redirect('getdata')
    return render(request, 'userregisteration.html',{'f':rform})

def login_view(request):
    if request.method=='POST':
        username=request.POST['username']
        password=request.POST['password']
        user=authenticate(request, username=username , password=password)
        if user is not None:
            login(request, user)
            return redirect('getdata')
        
    return render(request, 'login.html')


def logout_view(request):
    logout(request)
    return redirect('login')